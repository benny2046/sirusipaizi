

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Data Donasi</h2>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <a href="<?php echo e(route('donasi.create')); ?>" class="btn btn-success">Tambah Donasi</a>

        <table class="table mt-3">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>No HP</th>
                    <th>Jumlah</th>
                    <th>Bukti</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; ?>
                <?php $__currentLoopData = $donasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($no++); ?></td>
                        <td><?php echo e($donasi->nama); ?></td>
                        <td><?php echo e($donasi->no_hp); ?></td>
                        <td><?php echo e($donasi->jumlah); ?></td>
                        <td>
                            
                            <img src="<?php echo e(asset('storage/donasi/' . $donasi->bukti)); ?>" class="rounded" style="width: 150px">
                        
                        </td>
                        <td>
                            <form onsubmit="return confirm('Apakah Anda Yakin ?');" action="<?php echo e(route('donasi.destroy', $donasi->id)); ?>" method="POST">
                                <a href="<?php echo e(route('donasi.show', $donasi->id)); ?>" class="btn btn-sm btn-dark"><i class="fa fa-eye"></i></a>
                                <a href="<?php echo e(route('donasi.edit', $donasi->id)); ?>" class="btn btn-sm btn-success"><i class="fa fa-pencil-alt"></i></a>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($donasis->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\REVISI\sirusipaizi\resources\views/donasi/index.blade.php ENDPATH**/ ?>
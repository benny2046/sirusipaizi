

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Detail Reservasi</div>

                    <div class="card-body">
                        <p><strong>Nama:</strong> <?php echo e($reservasi['nama']); ?></p>
                        <p><strong>Phone:</strong> <?php echo e($reservasi['phone']); ?></p>
                        <p><strong>Alamat:</strong> <?php echo e($reservasi['alamat']); ?></p>
                        <p><strong>Kelurahan:</strong> <?php echo e($reservasi['kelurahan']); ?></p>
                        <p><strong>Kecamatan:</strong> <?php echo e($reservasi['kecamatan']); ?></p>
                        <p><strong>Kabupaten:</strong> <?php echo e($reservasi['kabupaten']); ?></p>
                        <p><strong>Provinsi:</strong> <?php echo e($reservasi['provinsi']); ?></p>
                        <p><strong>Jenis Kelamin:</strong> <?php echo e($reservasi['jeniskelamin']); ?></p>
                        <p><strong>Umur:</strong> <?php echo e($reservasi['umur']); ?></p>
                        <p><strong>Pendidikan:</strong> <?php echo e($reservasi['pendidikan']); ?></p>
                        <p><strong>Pekerjaan:</strong> <?php echo e($reservasi['pekerjaan']); ?></p>
                        <p><strong>Jenis Penyakit:</strong> <?php echo e($reservasi['jenis_penyakit']); ?></p>
                        <p><strong>Kategori Penyakit:</strong> <?php echo e($reservasi['kategori_penyakit']); ?></p>
                        <p><strong>Tanggal Masuk:</strong> <?php echo e($reservasi['tanggal_masuk']); ?></p>
                        <p><strong>Nama Pendamping:</strong> <?php echo e($reservasi['nama_pendamping']); ?></p>
                        <p><strong>Umur Pendamping:</strong> <?php echo e($reservasi['umur_pendamping']); ?></p>
                        <p><strong>Pendidikan Pendamping:</strong> <?php echo e($reservasi['pendidikan_pendamping']); ?></p>
                        <p><strong>Pekerjaan Pendamping:</strong> <?php echo e($reservasi['pekerjaan_pendamping']); ?></p>
                        <p><strong>Jenis Kelamin Pendamping:</strong> <?php echo e($reservasi['jeniskelaminpendamping']); ?></p>
                        <p><strong>Phone Pendamping:</strong> <?php echo e($reservasi['phone_pendamping']); ?></p>
                        <p><strong>Provinsi Pendamping:</strong> <?php echo e($reservasi['provinsi_pendamping']); ?></p>
                        <p><strong>Tanggal Masuk Pendamping:</strong> <?php echo e($reservasi['tanggal_masuk_pendamping']); ?></p>
                        <p><strong>File:</strong>
                        <?php if($reservasi['file']): ?>
                            <?php if(pathinfo($reservasi['file'], PATHINFO_EXTENSION) === 'pdf'): ?>
                                <!-- Menampilkan ikon PDF -->
                                <a href="<?php echo e(asset('storage/reservasi/' . $reservasi['file'])); ?>" target="_blank">
                                    <img src="<?php echo e(url('admin')); ?>/assets/images/pdf.png" alt="PDF Icon" width="20" height="20">
                                    <!-- Ganti 'nama_folder' dengan nama folder tempat Anda menyimpan file -->
                                </a>
                            <?php else: ?>
                                <!-- Jika bukan file PDF, tampilkan nama file -->
                                <p><strong>File:</strong> <a href="<?php echo e(asset('storage/reservasi/' . $reservasi['file'])); ?>" target="_blank"><?php echo e($reservasi['file']); ?></a></p>
                            <?php endif; ?>
                        <?php else: ?>
                            <p><strong>File:</strong> Tidak ada file terlampir</p>
                        <?php endif; ?>
                    </p>
                        <p><strong>Status:</strong> <?php echo e($reservasi['status']); ?></p>
                        <p><strong>User ID:</strong> <?php echo e($reservasi->user['name']); ?></p>

                        <a href="<?php echo e(route('reservasi.index')); ?>" class="btn btn-secondary">Kembali</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\REVISI\sirusipaizi\resources\views/reservasi/show.blade.php ENDPATH**/ ?>
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="shortcut icon" href="<?php echo e(url('admin')); ?>/assets/images/logo.ico" />

    <!-- FontAwesome JS-->
    <script defer src="<?php echo e(url('admin')); ?>/assets/plugins/fontawesome/js/all.min.js"></script>
    
    <!-- App CSS -->
    <link id="theme-style" rel="stylesheet" href="<?php echo e(url('admin')); ?>/assets/css/portal.css">
    <title>RSP IZI SUMBAR</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <link rel="shortcut icon" href="favicon.ico">

</head>

<body class="app app-login p-0">
    <div class="row g-0 app-auth-wrapper">
        <div class="col-12 col-md-7 col-lg-6 auth-main-col text-center p-5">
            <div class="d-flex flex-column align-content-end">
                <div class="app-auth-body mx-auto">
                    <div class="app-auth-branding mb-4"><a class="app-logo" href="#"><img class="logo-icon me-2"
                                src="<?php echo e(url('admin')); ?>/assets/images/logo.ico" alt="logo"></a></div>
                    <h2 class="auth-heading text-center mb-5">Log in to RSP IZI SUMBAR</h2>
                    <div class="auth-form-container text-start">
                        <form class="auth-form login-form" method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="email mb-3">
                                <label class="sr-only" for="email">Email Address</label>
                                <input id="email" name="email" type="email"
                                    class="form-control signin-email <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('email')); ?>" placeholder="Email Address" required
                                    autocomplete="email" autofocus>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="password mb-3">
                                <label class="sr-only" for="password">Password</label>
                                <input id="password" name="password" type="password"
                                    class="form-control signin-pasword <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Password" required autocomplete="current-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="extra mt-3 row justify-content-between">
                                    <div class="col-6">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="remember"
                                                id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                            <label class="form-check-label" for="remember">
                                                <?php echo e(__('Remember Me')); ?>

                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="forgot-password text-end"> <a
                                                href="<?php echo e(route('forgot-password')); ?>">
                                                <?php echo e(__('Lupa Password?')); ?>

                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn app-btn-success w-100 theme-btn mx-auto">
                                    Log In
                                </button>
                            </div>
                        </form>
                        <?php if(Route::has('register')): ?>
                            <div class="auth-option text-center pt-2">Belum punya akun? Registrasi<a class="text-link"
                                    href="<?php echo e(route('register')); ?>"> disini</a>.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-5 col-lg-6 h-100 auth-background-col">
            <div class="auth-background-holder">
            </div>
            <div class="auth-background-mask"></div>
        </div>
    </div>
    <!-- Javascript -->
    <script src="<?php echo e(url('admin')); ?>/assets/plugins/popper.min.js"></script>
    <script src="<?php echo e(url('admin')); ?>/assets/plugins/bootstrap/js/bootstrap.min.js"></script>

    <!-- Charts JS -->
    <script src="<?php echo e(url('admin')); ?>/assets/plugins/chart.js/chart.min.js"></script>
    <script src="<?php echo e(url('admin')); ?>/assets/js/index-charts.js"></script>

    <!-- Page Specific JS -->
    <script src="<?php echo e(url('admin')); ?>/assets/js/app.js"></script>
</body>

</html>
<?php /**PATH C:\REVISI\sirusipaizi\resources\views/auth/login.blade.php ENDPATH**/ ?>